import java.io.*;
import java.util.*;

public class App {

  public boolean isItPerfectImperative(int a){
      int sum = 1;
      if(a < 6){
        return false;
      }

      for(int i = 2; i < a; i++){
        if(a % i == 0){
          sum+=i;
        }
      }
      return (sum == a);
  }

  public boolean isItPerfectFunctional(int number, int currentNumber, int currentTotal){

    if(number == 0){
      return false;
    }
    
    if(currentNumber == 0){
      return (currentTotal == 2*number);
    }

    else if(number % currentNumber == 0){
      return isItPerfectFunctional(number, currentNumber-1, currentTotal+currentNumber);
    }

    return isItPerfectFunctional(number, currentNumber-1, currentTotal);
  }
}
