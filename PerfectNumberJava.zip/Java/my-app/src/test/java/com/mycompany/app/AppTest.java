import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest
{
    /*Imperative Unit Tests*/
    @Test
    public void testPerfectNumberImperative6(){
      App perNum = new App();
      assertTrue(perNum.isItPerfectImperative(6));
    }

    @Test
    public void testPerfectNumberImperative28(){
      App perNum = new App();
      assertTrue(perNum.isItPerfectImperative(28));
    }

    @Test
    public void testPerfectNumberImperative8128(){
      App perNum = new App();
      assertTrue(perNum.isItPerfectImperative(8128));
    }

    @Test
    public void testPerfectNumberImperative0(){
      App perNum = new App();
      assertTrue(!perNum.isItPerfectImperative(0));
    }

    /*Functional Unit Tests*/
    @Test
    public void isItPerfectFunctional0(){
      App perNum = new App();
      assertTrue(!perNum.isItPerfectFunctional(0, 0, 0));
    }

    @Test
    public void isItPerfectFunctional28(){
      App perNum = new App();
      assertTrue(perNum.isItPerfectFunctional(28, 28, 0));
    }

    @Test
    public void isItPerfectFunctional6(){
      App perNum = new App();
      assertTrue(perNum.isItPerfectFunctional(6, 6, 0));
    }

    @Test
    public void isItPerfectFunctional55(){
      App perNum = new App();
      assertTrue(!perNum.isItPerfectFunctional(55, 55, 0));
    }

    @Test
    public void isItPerfectFunctional8128(){
      App perNum = new App();
      assertTrue(perNum.isItPerfectFunctional(8128, 8128, 0));
    }
}
