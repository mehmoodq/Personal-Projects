module Fibonacci where

fibRecursive :: Int -> [Int]
fibRecursive 0 = [1]
fibRecursive 1 = [1, 1]
fibRecursive n = newSeries where
  newSeries = series ++ [sum (drop (n - 2) series)]
  series = fibRecursive(n - 1)

fibIterative :: Int -> [Int]
fibIterative 0 = [1]
fibIterative 1 = [1, 1]
fibIterative n = foldl (\series ignore -> series ++ [sum (drop (length series - 2) series)]) [1, 1] [2..n]

fibIterRecur :: Int -> [Int] -> [Int]
fibIterRecur 0 series = [1]
fibIterRecur 1 series = series
fibIterRecur n series = fibIterRecur (n - 1) (series ++ [sum (drop (length series - 2) series)])libraryDependencies += "org.scala-lang.modules" %% "scala-parser-combinators" % "1.1.0"