cabal install tasty
cabal install tasty-hunit
cabal configure --enable-tests
cabal build
cabal test 
/bin/rm -rf cabal.project.local
/bin/rm -rf cabal.project.local~
/bin/rm -rf dist-newstyle