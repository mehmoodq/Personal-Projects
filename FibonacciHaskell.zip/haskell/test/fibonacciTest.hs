import Test.Tasty (defaultMain, testGroup)
import Test.Tasty.HUnit (assertEqual, testCase)
import Fibonacci (fibRecursive, fibIterative, fibIterRecur)

main = defaultMain unitTests

unitTests =
  testGroup
    "Unit tests"
    [canary, testFib1, testFib2, testFib3, testFib4, testFib5, testFibIterative1, testFibIterative3, testFibIterative5, testIterRecur0, testIterRecur1, testIterRecur3, testIterRecur5]

canary =
  testCase "canary" $ assertEqual [] True (True)

testFib1 =
  testCase "fib 1" $ assertEqual [] [1, 1] (fibRecursive 1)
  
testFib2 =
  testCase "fib 2" $ assertEqual [] [1, 1, 2] (fibRecursive 2)
  
testFib3 =
  testCase "fib 3" $ assertEqual [] [1, 1, 2, 3] (fibRecursive 3)
  
testFib4 =
  testCase "fib 4" $ assertEqual [] [1, 1, 2, 3, 5] (fibRecursive 4)
  
testFib5 =
  testCase "fib 5" $ assertEqual [] [1, 1, 2, 3, 5, 8] (fibRecursive 5)

testFibIterative1 =
  testCase "fibIterative 1" $ assertEqual [] [1, 1] (fibIterative 1)

testFibIterative3 =
  testCase "fibIterative 3" $ assertEqual [] [1, 1, 2, 3] (fibIterative 3)

testFibIterative5 =
  testCase "fibIterative 5" $ assertEqual [] [1, 1, 2, 3, 5, 8] (fibIterative 5)
  
testIterRecur0 = 
  testCase "fibIterRecur 0" $ assertEqual [] [1] (fibIterRecur 0 [1, 1])

testIterRecur1 = 
  testCase "fibIterRecur 1" $ assertEqual [] [1, 1] (fibIterRecur 1 [1, 1])
	
testIterRecur3 = 
  testCase "fibIterRecur 3" $ assertEqual [] [1, 1, 2, 3] (fibIterRecur 3 [1, 1])
	
testIterRecur5 = 
  testCase "fibIterRecur 5" $ assertEqual [] [1, 1, 2, 3, 5, 8] (fibIterRecur 5 [1, 1])