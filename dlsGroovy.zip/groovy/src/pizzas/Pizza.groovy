package pizzas

class Pizza {
  def layers = []

  def spread(item) {
    layers << item
  }

  def toppings(... items) {
    layers << "toppings: ${items.join(', ')}"
  }

  def propertyMissing(name) {
    return name
  }

  def getBake() {
    layers << 'baked'
  }

  String toString() {
    return "Pizza: ${layers.join(', ')}".trim()
  }

}
