package pizzas

class PizzaMaker {
  def create(pizza, closure = {}) {
    def pizzaObject = pizza.newInstance()
    pizzaObject.with closure

    pizzaObject
  }

  def evaluate(dsl) {
    def bindings = new Binding()
    bindings.setVariable('Pizza', Pizza)

    def closure = new GroovyShell(bindings).evaluate("{ -> $dsl }")
    closure.delegate = this

    closure().toString()
  }

}
