package pizzas

import spock.lang.Specification

class PizzaMakerTest extends Specification {

  PizzaMaker pizzaMaker

  void setup() {
      pizzaMaker = new PizzaMaker()
  }

  def "test Canary"() {
    expect:
      true == true
  }

  def 'create pizza creates an object of type Pizza'() {
    def result = pizzaMaker.evaluate('create Pizza')

    expect:
      result == 'Pizza:'
  }

  def 'spread sauce '() {
    def result = pizzaMaker.evaluate("""
      create Pizza, {
        spread sauce
      }
    """)

    expect:
      result == 'Pizza: sauce'
   }


  def 'spread cheese'() {
    def result = pizzaMaker.evaluate("""
      create Pizza, {
        spread cheese
      }
    """)

    expect:
      result == 'Pizza: cheese'
   }

  def 'topping option 1'() {
    def result = pizzaMaker.evaluate("""
      create Pizza, {
        toppings tomatoes, onions, green_peppers
      }
    """)

    expect:
      result == 'Pizza: toppings: tomatoes, onions, green_peppers'
   }


  def 'topping option 2'() {
    def result = pizzaMaker.evaluate("""
      create Pizza, {
        toppings tomatoes, crushed_peppers
      }
    """)

    expect:
      result == 'Pizza: toppings: tomatoes, crushed_peppers'
  }

   def 'topping option 3'() {
    def result = pizzaMaker.evaluate("""
      create Pizza, {
        toppings onions
      }
    """)

    expect:
      result == 'Pizza: toppings: onions'
   }

  def 'add all ingredients and bake pizza'() {
    def result = pizzaMaker.evaluate('''
      create Pizza, {
        spread sauce
        spread cheese
        toppings tomatoes, onions, green_peppers
        bake
      }
    ''')

    expect:
      result == "Pizza: sauce, cheese, toppings: tomatoes, onions, green_peppers, baked"
  }
}
