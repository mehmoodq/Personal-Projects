const { functional, imperative } = require('../src/perfectNumbers');

function testH(tuple){
    const [input, output] = tuple;
    test(`${input} => ${output ? "perfect" : "not perfect"}`, ()=>{
        expect(
            imperative.isPerfectNumber(input) &&
            functional.isPerfectNumber(input)
        ).toBe(output);
    })
}

const tuples = [
    [6, true],
    [28, true],
    [496, true],
    [8128, true],
    [33550336, true],
    [0, false],
    [1, false],
    [32, false],
    [112, false],
    [99599, false],
]

for(var tuple of tuples){
    testH(tuple);
}