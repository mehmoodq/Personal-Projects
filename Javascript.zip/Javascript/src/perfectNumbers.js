const imperative = (function(){
    //private

    /**
     * Returns unique factors
     * @param {int} x - number in question 
     */
    function getFactors(x){
        if(x < 0 || x % 1 != 0){
            throw "Please enter an integer greater than or equal to zero.";
        }

        var factors = [];
        const n = x**(1/2);
        for(var i = 1; i <= n; i++){
            if(x % i == 0){
                factors.push(i);
                //assuming that only unique numbers are wanted
                if(i != n){
                    factors.push(x / i);
                }
            }
        }
        return factors;
    }

    /**
     * Returns sum of an array
     * @param {array<number>} a - a list of numbers
     */
    function sumArray(a){
        var rSum = 0;
        for(var i of a){
            rSum += i;
        }
        return rSum;
    }

    //public
    return {
        /**
         * Checks if is a 'perfect number'
         * @param {int} x - number in question 
         */
        "isPerfectNumber": function(x){
            const factors = getFactors(x);
            const sumOfFactors = sumArray(factors);
            
            return x != 0 && sumOfFactors == x * 2;
        }
    }
})();

const functional = (function(){
    //private
    
    /**
     * Returns sum of the unique factors. The recursive helper function.
     * @param {int} x - number in question
     * @param {int} i - current index
     * @param {int} s - current sum
     */
    function getSumOfFactorsH(x, i, s){
        if(i > x**(1/2)){
            return s;
        }
        else if(x % i != 0){
            return getSumOfFactorsH(x, i + 1, s);
        }
        //assuming that only unique numbers are wanted
        else if(i == x**(1/2)){
            return getSumOfFactorsH(x, i + 1, s + i);
        }
        else{
            return getSumOfFactorsH(x, i + 1, s + i + (x / i));
        }
    }

    /**
     * Returns the sum of the unique factors.
     * @param {int} x - number in question
     */
    function getSumOfFactors(x){
        if(x < 0 || x % 1 != 0){
            throw "Please enter an integer greater than or equal to zero.";
        }
        return getSumOfFactorsH(x, 1, 0);
    }

    //public
    return {
        /**
         * Checks if is a 'perfect number'
         * @param {int} x - number in question 
         */
        "isPerfectNumber": function(x){
            return x != 0 && getSumOfFactors(x) == 2 * x;
        }
    }
})();

module.exports = {
    "imperative": imperative,
    "functional": functional,
}


if(process.argv[2]){
    const input = process.argv[2];
    console.log("Input:", input);
    console.log("Imperative:", imperative.isPerfectNumber(input) );
    console.log("Functional:", functional.isPerfectNumber(input) );
}