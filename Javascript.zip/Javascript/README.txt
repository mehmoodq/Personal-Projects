command line:

npm test
//Runs unit tests

npx webpack
//Builds ./src/perfectNumbers.js and
//distributes to ./dist/bundle.js