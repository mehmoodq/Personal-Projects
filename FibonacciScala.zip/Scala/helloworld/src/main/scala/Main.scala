object Main extends App {
  println("Hello, World!!")

  def fibonacciIterative(n: Int): Int = {
    var a1: Int = 0
    var a2: Int = 1
    var a3: Int = a1 + a2;

    for(i <- 0 to n){
      a3 = a1 + a2;
      a1 = a2;
      a2 = a3;
    }

    return a1
  }

  def fibonacciRecursive(n: Int): Int = {
    if(n == -1) return 0;
    if(n == 0) return 1;
    return fibonacciRecursive(n-1) + fibonacciRecursive(n-2);
  }
}