class Fib{
    def fibRecursive(n: Int): List[Int] = {
        if(n == 0) return List(1)
        if(n == 1) return List(1, 1)
        val prev = fibRecursive(n-1)
        return prev ++ Seq(prev.takeRight(2).sum)
    }

    def fibIterative(n: Int): List[Int] = {
        if(n == 0) return List(1)
        if(n == 1) return List(1, 1)
        var crnt = List(1, 1)
        for(i <- (2 to n).toList){
            crnt = crnt ++ Seq(crnt.takeRight(2).sum)
        }
        return crnt
    }
}