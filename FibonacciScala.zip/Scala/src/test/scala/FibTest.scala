import org.junit.Test
import org.junit.Assert._

class FibonnaciSeriesTest {
  var fib = new Fib()
     
  @Test
  def testFibRecursivePosition0() = {
    var exepectedResult = List(1)
    assertEquals(exepectedResult, fib.fibRecursive(0))
  }
   
  @Test
  def testFibRecursivePosition1() = {
    var exepectedResult = List(1, 1)
    assertEquals(exepectedResult, fib.fibRecursive(1))
  }

  @Test
  def testFibRecursivePosition2() = {
    var exepectedResult = List(1, 1, 2)
    assertEquals(exepectedResult, fib.fibRecursive(2))
  }
   
  @Test
  def testFibRecursivePosition3() = {
    var exepectedResult = List(1, 1, 2, 3, 5, 8, 13, 21, 34)
    assertEquals(exepectedResult, fib.fibRecursive(8))
  }

  @Test
  def testFibIterativePosition0() = {
    var exepectedResult = List(1)
    assertEquals(exepectedResult, fib.fibIterative(0))
  }
   
  @Test
  def testFibIterativePosition1() = {
    var exepectedResult = List(1, 1)
    assertEquals(exepectedResult, fib.fibIterative(1))
  }

  @Test
  def testFibIterativePosition2() = {
    var exepectedResult = List(1, 1, 2)
    assertEquals(exepectedResult, fib.fibIterative(2))
  }
   
  @Test
  def testFibIterativePosition3() = {
    var exepectedResult = List(1, 1, 2, 3, 5, 8, 13, 21, 34)
    assertEquals(exepectedResult, fib.fibIterative(8))
  }
}