object Fib{
    def main(args: Array[String]){
        val input: Int = args(0).toInt
        printList(fibRecursive(input))
        
    }

    def printList(iterable: List[Int]){
        println(for{ i <- iterable } yield i)
    }

    def fibRecursive(n: Int): List[Int] = {
        if(n == 0) return List(1)
        if(n == 1) return List(1, 1)
        val prev = fibRecursive(n-1)
        return prev ++ Seq(prev.takeRight(2).sum)
    }
}