-module(fibonacci_test).
-include_lib("eunit/include/eunit.hrl").

fibonacciSeriesRecursivePosition0_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesRecursive(0), [1]).

fibonacciSeriesRecursivePosition1_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesRecursive(1), [1, 1]).

fibonacciSeriesRecursivePosition2_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesRecursive(2), [1, 1, 2]).

fibonacciSeriesRecursivePosition3_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesRecursive(3), [1, 1, 2, 3]).

fibonacciSeriesRecursivePosition4_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesRecursive(4), [1, 1, 2, 3, 5]).

fibonacciSeriesTailRecursivePosition0_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesTailRecursive(0), [1]).

fibonacciSeriesTailRecursivePosition1_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesTailRecursive(1), [1, 1]).

fibonacciSeriesTailRecursivePosition2_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesTailRecursive(2), [1, 1, 2]).

fibonacciSeriesTailRecursivePosition3_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesTailRecursive(3), [1, 1, 2, 3]).

fibonacciSeriesTailRecursivePosition4_test_() -> ?_assertEqual(fibonacci:fibonacciSeriesTailRecursive(4), [1, 1, 2, 3, 5]).

fibonacciSeriesIterative_test2_() -> ?_assertEqual(fib:fib(2), 2).

fibonacciSeriesIterative_test3_() -> ?_assertEqual(fib:fib(3), 3).

fibonacciSeriesIterative_test4_() -> ?_assertEqual(fib:fib(4), 5).