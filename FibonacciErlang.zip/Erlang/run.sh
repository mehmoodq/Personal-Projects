rebar clean
rebar eunit
rebar clean